# Changelog

## 0.1.0

- Initial Borderlands GOTY Enhanced raw-data extractor, author keogh.
- F9 start/pause/resume; menu controls for status, fresh captures and partial exports.
- Reflected definitions, class/struct schemas, typed references, parts, balance rules, loot graphs and limited current-map source bindings.
- Reviewed base-game/DLC data-package plan; missing, failed and interrupted package loads recorded explicitly.
- Bounded main-thread processing, temporary data-asset liveness pins and lifecycle cleanup.
- Atomic, checksummed JSON chunks, validated recovery, session provenance and incremental ZIP packaging.
- Standalone project layout; final family compiler deferred.
