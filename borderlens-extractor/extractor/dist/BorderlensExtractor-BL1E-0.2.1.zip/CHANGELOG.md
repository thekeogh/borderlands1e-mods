# Changelog

## 0.2.1

- Start a fresh capture when the last-export pointer references a deleted folder or missing manifest. Preserve remaining files and continue rejecting corrupt checkpoints.
- Include missing file paths in startup error messages.
- Add deleted-folder and deleted-manifest regression tests.

## 0.2.0

- Follow expression trees/evaluators and non-actor population factories to collect missing calculation and source relationships.
- Recover nested objects through separator variants and exact-class enumeration, validating full path, class and process-local address.
- Use the same lookup checks when releasing temporary asset pins; report unresolved releases explicitly.
- Record lookup recovery diagnostics, streamed-level provenance and per-record source packages.
- Expand the reviewed package plan from 48 to 69 roots using real capture evidence, including additional DLC items, custom weapons, elemental rules and population data. Remove two unconfirmed candidate names.
- Automatically start a fresh capture after upgrading rather than resuming an incompatible extractor version. Existing exports remain intact.
- Add regression fixtures from the first BL1E capture and tests for graph traversal, nested lookup, identity checks and upgrade behavior.

## 0.1.0

- Initial Borderlands GOTY Enhanced raw-data extractor, author keogh.
- F9 start/pause/resume; menu controls for status, fresh captures and partial exports.
- Reflected definitions, class/struct schemas, typed references, parts, balance rules, loot graphs and limited current-map source bindings.
- Reviewed base-game/DLC data-package plan; missing, failed and interrupted package loads recorded explicitly.
- Bounded main-thread processing, temporary data-asset liveness pins and lifecycle cleanup.
- Atomic, checksummed JSON chunks, validated recovery, session provenance and incremental ZIP packaging.
- Standalone project layout; final family compiler deferred.
