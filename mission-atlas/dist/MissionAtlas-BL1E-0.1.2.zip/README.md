# Mission Atlas

**0.1.2 · keogh · Borderlands GOTY Enhanced**

Show faded diamonds for other accepted missions on your current map. Your tracked
mission keeps its normal marker. Ready-to-turn-in missions use their hand-in
location; offers and paid missions are excluded.

## Install and test

1. **Close the game completely.** Replace `sdk_mods/MissionAtlas.sdkmod` with the
   archive from `dist/MissionAtlas.sdkmod`, then launch and enable Mission Atlas.
2. Load a character with multiple accepted missions on the same map. Track one
   whose objective is on that map, open the map, and look for faded diamonds.
3. Pan, zoom, change the tracked mission, and try a ready-to-turn-in mission.
4. While on the map press **F9**, or use **Export Mission Atlas diagnostics** in
   Mods. Send the JSON from `sdk_mods/settings/MissionAtlas/diagnostics/`.

Options: **Show turn-in markers** and **Other mission opacity**. Runs separately
from One Playthrough; mission progress, rewards and save files are unchanged.

## What changed

The 0.1.1 report confirmed that a duplicate diagnostic hook aborted discovery
before the map helper was inspected. It also showed repeated actor scans on
panning. 0.1.2 uses one callback per map event, function-specific hook IDs,
registration failure isolation, and cached location scans once per second.
It removes the speculative getter/marker-writer hooks from earlier versions.

Rendering now uses the captured `MapObjects` objective clip, duplicates it into
unique Mission Atlas clips in the same map container, and sets their positions
and opacity. Native map icons calibrate world-to-map coordinates, preserving the
game's own pan/zoom/rotation. Original icons and the native `MapObjects` array
are read-only. Extra clips have no copied click handlers or mission-selection
behaviour. Disabling removes only the mod's own clips.

## Prototype limits

**The Flash rendering path still needs Windows verification.** Native methods,
ASValue fields and enum values are checked against reflected signatures before
any UI calls. Unsupported interfaces stay native and appear in the export;
failed probes back off instead of repeating on every mouse movement.

Only loaded waypoint actors matching the accepted mission's waypoint definition
and current map qualify. A mission may have several authored waypoint locations;
this prototype can show several diamonds for that mission. Exact objective-step
filtering and tooltips for the extra diamonds are not implemented. Co-op is
unverified. Compass/HUD markers are unchanged.

## Development

`python3 -m unittest discover -s tests` runs local models, including uploaded
BL1E map-data fixtures. These do not execute the Windows renderer.
`python3 package.py` builds the SDK mod and versioned ZIP.

Native class research references:
[MOW531's Mission Selector](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Mission%20Selector)
and [Extended Item Cards](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Experimental%20mods/Extended%20Item%20Cards).
No external mod implementation is bundled.
