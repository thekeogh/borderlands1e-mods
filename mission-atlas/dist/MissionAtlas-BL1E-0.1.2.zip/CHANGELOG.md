# Mission Atlas changelog

## 0.1.2 — 2026-11-06

- Fix the new captured failure: duplicate PanMap observation registration aborted
  discovery before reaching WillowGFxHelperMap. Use function-specific identifiers,
  clean owned legacy hooks and isolate registration failures. Use one post hook
  per map event; never replay or block native panning.
- Remove per-pan actor reflection and speculative marker getter/writer hooks.
  Cache primitive waypoint positions for one second and invalidate on mission
  changes. Stop periodic schema discovery once the map interfaces are ready.
- Render dedicated Flash copies of the captured MapObjects objective icon using
  checked Invoke/GetVariableNumber/SetVariableNumber signatures (including compatible
  reflected aliases). Resolve ASValue enum values from metadata, never guessed IDs.
- Calibrate coordinates from native icons with explicit world locations. Validate
  alignment, allocate depths through the map container, verify created clip depth
  and alpha, deduplicate clips, and update only changed positions/opacity.
  Native icons and MapObjects stay unchanged; extra clips are noninteractive.
- Clean owned clips on mission removal, disable and map changes. Rebuild verified
  clips after native container replacement. Throttle redraw work and back off
  failed interface probes. Export renderer plans, errors and primitive caches.
- Validation: 32 local tests pass, including captured Trash map coordinates,
  duplicate registration isolation, cache/throttle counters, pan/zoom alignment,
  clip ownership, cleanup and failed creation. Windows rendering remains unverified.

## 0.1.1 — 2026-11-06

- Fix the confirmed 0.1.0 hook-path bug: use UFunction declaring class and name,
  preserving BL1E's `Package.Class:Function` form. The first report had zero map
  scopes, zero marker adapters, and no observed calls despite accepted local missions.
- Register the actual captured SetupMapPage, extUpdateMapPage and MapUpdateBehavior
  entry points. Accept world-owned mission trackers in the current world.
- Discover the confirmed WillowGFxHelperMap class. Reuse tracked-marker templates
  only through compatible UI-only writers with reflected world-vector/waypoint inputs;
  skip caller-owned IDs and unsupported output parameters. Retain native results,
  deduplicate extras per build, and never retry native creation after an exception.
- Add an F9 fallback on the map's native input handler. Expand manual reports with
  raw function paths, helper schemas/values, nested structs, tracker ownership and
  player replication waypoint data. Native helper rendering still needs testing.
- Validation: 37 local tests pass, including a regression fixture from the uploaded
  report, real-format hook names, world-owned trackers, captured current-map missions,
  marker forwarding/fading and failure handling. No Windows rendering claim.

## 0.1.0 — 2026-11-06

- First standalone BL1E map-marker prototype. Select accepted, untracked missions
  from the current playthrough and exact current map, including optional turn-ins.
- Match loaded waypoint actors through reflected WaypointDefinition references.
  Supply extra markers through compatible native getters/predicates during map UI
  calls only; preserve original getter invocation and return on failures.
- Temporarily fade extra marker colours where native colour interfaces exist.
  Restore owned properties after nested calls, failures or disabling.
- Add bounded native interface/call diagnostics, exported manually with F9 or
  the Mods option. Native Windows map rendering is not yet verified; unsupported
  interfaces remain unchanged and need an in-game report for the next iteration.
- Validation: 25 local model tests pass, including mission/map filtering, shared
  tracked locations, native-call forwarding, failure cleanup and SDK registration.
