# Mission Atlas

**0.1.7 · keogh · Borderlands GOTY Enhanced**

Show one faded diamond per other accepted mission on your current map. Your tracked
mission keeps its normal marker. Ready-to-turn-in missions use their hand-in
location; offers and paid missions are excluded. Hover an extra diamond with the
mouse or controller focus to show its mission name; labels are hidden otherwise.

## Install and test

1. **Close the game completely.** Replace `sdk_mods/MissionAtlas.sdkmod` with the
   archive from `dist/MissionAtlas.sdkmod`, then launch and enable Mission Atlas.
2. Load a character with multiple accepted missions on the same map. Track one
   whose objective is on that map, open the map, and wait briefly without touching
   the controls. Extra diamonds should appear automatically.
3. Pan, zoom, change the tracked mission, and try a ready-to-turn-in mission.
   Hover/focus an extra diamond: its mission name should appear only while hovered.
   Move away and check the label disappears; native icon tooltips should stay unchanged.
4. While on the map press **F9**, or use **Export Mission Atlas diagnostics** in
   Mods. Send the JSON from `sdk_mods/settings/MissionAtlas/diagnostics/`.

Options: **Show turn-in markers** and **Other mission opacity**. Runs separately
from One Playthrough; mission progress, rewards and save files are unchanged.

## What changed

0.1.7 is a tooltip diagnostic build. The 0.1.6 report confirms six live,
enabled clips and 235 tooltip queries, yet neither mouse nor controller shows
labels. Enabling/refreshing alone does not solve the native binding problem.
Marker rendering remains unchanged; tooltips are still unconfirmed.

To capture the missing native setup:

1. Close the game, replace the SDK archive, then relaunch.
2. In Mods, choose **Export Mission Atlas diagnostics**.
3. Reopen the map and pan briefly. Four real native map updates are recorded.
4. Upload the newest **mission-atlas-native-map-*.json** from the diagnostics folder.
   It saves automatically; no F9 or second export is needed.

This manually requested capture observes actual icon setup, including reflected
ActionScript bridges and inherited overrides. Temporary Flash observers exist
only inside each native ApplyFlash call and are removed before Atlas draws.
Capture stops after four calls, after two minutes, on travel or disable. The
normal immediate export still works. No native map creation/panning is replayed.

Tooltip registration uses owned metadata for verified Mission Atlas clips in the native map
helper. It adds only owned rows; existing native rows keep their values and order.
The game handles hover hit-testing and controller focus using its own tooltip query.
No always-on label or copied click-to-select handler is added. Mission changes,
map rebuilds and disabling remove/update only the owned entries. Tooltip failures
leave the diamonds working and appear separately in the diagnostic export.


0.1.3 selects one location per mission instead of drawing every authored waypoint.
A mission-wide waypoint (number zero) takes priority. Otherwise, native objective
requirements and current amounts select the first unfinished numbered objective.
If counters are unavailable, use one stable numbered location as a fallback.
Mission keys stay stable as the selected objective changes.

Opening the map can precede its native icon creation. A focused post-ApplyFlash
hook and a bounded viewport retry now render as soon as those icons are ready,
without waiting for input. Positions remain cached once per second; pan/zoom
updates do not scan actor properties. Retry work stops after startup succeeds,
the menu closes, the mod is disabled, or five seconds elapse.

Rendering now uses the captured `MapObjects` objective clip, duplicates it into
unique Mission Atlas clips in the same map container, and sets their positions
and opacity. Native map icons calibrate world-to-map coordinates, preserving the
game's own pan/zoom/rotation. Original icons and native map-object entries remain unchanged. Owned tooltip
entries are appended to `MapObjects` and removed on cleanup. Extra clips have no
copied click handlers or mission-selection behaviour. Disabling removes only the mod's own clips.

## Prototype limits

**Marker layout, startup and performance were confirmed in-game through 0.1.4.**
The revised hover/focus behavior in 0.1.6 still needs in-game verification. Native methods,
ASValue fields and enum values are checked against reflected signatures before
any UI calls. Unsupported interfaces stay native and appear in the export;
failed probes back off instead of repeating on every mouse movement.

Only loaded waypoint actors matching the accepted mission's waypoint definition
and current map qualify. Numbered-objective selection uses native counters;
unusual mission layouts may need refinement. Shared locations can overlap.
Tooltip hover/focus uses the native map behavior; mouse and controller need
in-game testing. Co-op is unverified. Compass/HUD markers are unchanged.

## Development

`python3 -m unittest discover -s tests` runs local models, including uploaded
BL1E map-data fixtures. These do not execute the Windows renderer.
`python3 package.py` builds the SDK mod and versioned ZIP.

Native class research references:
[MOW531's Mission Selector](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Mission%20Selector)
and [Extended Item Cards](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Experimental%20mods/Extended%20Item%20Cards).
No external mod implementation is bundled.
