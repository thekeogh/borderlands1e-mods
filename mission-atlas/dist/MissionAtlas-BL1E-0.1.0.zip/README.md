# Mission Atlas

**0.1.0 · keogh · Borderlands GOTY Enhanced**

First in-game prototype: show additional accepted missions on your current map,
using faded blue diamonds where the native map exposes compatible waypoint and
colour interfaces. Your tracked mission keeps its normal marker. Ready-to-turn-in
missions use their hand-in location; offers and paid missions are excluded.

## Install and test

1. Close the game. Copy `dist/MissionAtlas.sdkmod` into its `sdk_mods` folder.
2. Launch and enable **Mission Atlas** in Mods. It runs separately from One Playthrough.
3. Load a character with at least two accepted missions with current objectives
   on the same map. Track one, then open the map and look for the other marker.
4. Change the tracked mission, reopen the map, and check again. Try a ready-to-turn-in
   mission too. The options include turn-in markers and extra-marker opacity.
5. **While the map is open, press F9**, then send the generated JSON from
   `sdk_mods/settings/MissionAtlas/diagnostics/`. Export once even if it works.
   The Mods options also have **Export Mission Atlas diagnostics**.

## Prototype limits

**Extra markers are not yet verified in the Windows game.** This build discovers
actual native signatures rather than assuming BL2 interfaces work in BL1E.
It supplies additional waypoint actors only through recognized read-only getters
and tracked-mission visibility predicates during native map UI calls. If the
map builds its list through a different internal path, no extra markers will
appear yet; F9 records the actual functions, fields and calls needed to implement
that path. Colour also depends on an exposed native property or colour getter.

Only loaded waypoint actors matching a mission's current waypoint definition and
current map are candidates. Undiscovered/unloaded locations may not appear.
No objectives, mission statuses, rewards or save files are edited. The mod never
cycles your active mission or invokes the native waypoint resolver. Compass/HUD
markers are outside this prototype's scope. Co-op is unverified.

## Development

`python3 -m unittest discover -s tests` runs local models; these do not execute
Windows map rendering. `python3 package.py` builds the SDK mod and versioned ZIP.

Native research references: the local game capture's `MissionDefinition` and
`WaypointDefinition` schemas, and MOW531's public
[Mission Selector](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Mission%20Selector)
/ [Extended Item Cards](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Experimental%20mods/Extended%20Item%20Cards)
for BL1 class names. No external mod implementation is bundled.
