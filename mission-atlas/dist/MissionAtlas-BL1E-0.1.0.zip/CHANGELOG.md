# Mission Atlas changelog

## 0.1.0 — 2026-11-06

- First standalone BL1E map-marker prototype. Select accepted, untracked missions
  from the current playthrough and exact current map, including optional turn-ins.
- Match loaded waypoint actors through reflected WaypointDefinition references.
  Supply extra markers through compatible native getters/predicates during map UI
  calls only; preserve original getter invocation and return on failures.
- Temporarily fade extra marker colours where native colour interfaces exist.
  Restore owned properties after nested calls, failures or disabling.
- Add bounded native interface/call diagnostics, exported manually with F9 or
  the Mods option. Native Windows map rendering is not yet verified; unsupported
  interfaces remain unchanged and need an in-game report for the next iteration.
- Validation: 25 local model tests pass, including mission/map filtering, shared
  tracked locations, native-call forwarding, failure cleanup and SDK registration.
