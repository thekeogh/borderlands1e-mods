# Mission Atlas

**0.1.1 · keogh · Borderlands GOTY Enhanced**

In-game prototype: show additional accepted missions on your current map,
using faded blue diamonds where the native map exposes compatible waypoint and
colour interfaces. Your tracked mission keeps its normal marker. Ready-to-turn-in
missions use their hand-in location; offers and paid missions are excluded.

## Install and test

1. Close the game. Copy `dist/MissionAtlas.sdkmod` into its `sdk_mods` folder.
2. Launch and enable **Mission Atlas** in Mods. It runs separately from One Playthrough.
3. Load a character with at least two accepted missions with current objectives
   on the same map. Track one, then open the map and look for the other marker.
4. Change the tracked mission, reopen the map, and check again. Try a ready-to-turn-in
   mission too. The options include turn-in markers and extra-marker opacity.
5. **While the map is open, press F9**, then send the generated JSON from
   `sdk_mods/settings/MissionAtlas/diagnostics/`. Export once even if it works.
   The Mods options also have **Export Mission Atlas diagnostics**.

## Prototype limits

**Extra markers are not yet verified in the Windows game.** The 0.1.0 report
showed zero map hooks and zero marker adapters: function paths were incorrectly
formatted, and the tracker ownership check rejected a world-owned tracker.
0.1.1 fixes those paths, uses the captured `SetupMapPage` / `MapUpdateBehavior`
entry points, and discovers the actual `WillowGFxHelperMap` class.

Compatible waypoint queries can supply extra actors. A compatible UI marker writer
can reuse a native tracked-marker template at the other actors' world positions;
caller-assigned IDs and unsupported output signatures stay native. Only confirmed
tracked waypoint coordinates qualify as a template. Colours/alpha are applied
through exposed UI arguments or newly created Flash icons when available.
For this test, track a mission whose objective is on the current map.

The report did not include the map helper's functions, so its marker-writing API
still needs native verification. If there are still no diamonds, export another
report: it now includes that helper's schemas, nested data, live values and calls.
The map input handler also has an F9 fallback; the Mods export remains available.
Close/reopen the map after disabling the prototype to discard any extra UI icons.

Only loaded waypoint actors matching a mission's current waypoint definition and
current map are candidates. Undiscovered/unloaded locations may not appear.
No objectives, mission statuses, rewards or save files are edited. The mod never
cycles your active mission or invokes the native waypoint resolver. Compass/HUD
markers are outside this prototype's scope. Co-op is unverified.

## Development

`python3 -m unittest discover -s tests` runs local models; these do not execute
Windows map rendering. `python3 package.py` builds the SDK mod and versioned ZIP.

Native research references: the local game capture's `MissionDefinition` and
`WaypointDefinition` schemas, and MOW531's public
[Mission Selector](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Mission%20Selector)
/ [Extended Item Cards](https://github.com/MOW531/MOW531-BL1-SDK-Mods/tree/master/Experimental%20mods/Extended%20Item%20Cards)
for BL1 class names. No external mod implementation is bundled.
